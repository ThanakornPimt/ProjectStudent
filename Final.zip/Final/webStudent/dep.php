<!DOCTYPE html>
<html>
<head>
 <title>Bootstrap Select</title>
<meta charset="utf-8">

<link rel="stylesheet" href="../nice/s/dist/css/bootstrap-select.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<script src="../nice/s/dist/js/bootstrap-select.js"></script>
</head>
<body>
<form class="form-inline">
    <div class="form-group">
        <label class="col-md-3 control-label" for="select-testing">select:</label>
    </div>
    <div class=”form-group”>
        <select id="select-testing" class="selectpicker" data-live-search="true" title="Please select">
            <option>Ant</option>
            <option>Bat</option>
            <option>Cat</option>
            <option>Dog</option>
            <option>Egg</option>
        </select>
        <select id="select-testing" class="selectpicker" data-live-search="true" >
            <option>Ant</option>
            <option>Bat</option>
            <option>Cat</option>
            <option>Dog</option>
            <option>Egg</option>
        </select>
     </div>
</form>
</body>
</html>